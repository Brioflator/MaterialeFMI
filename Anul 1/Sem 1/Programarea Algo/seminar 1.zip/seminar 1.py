
x = 14
# print(bin(x))
# print(bin(-x))


# ~
# 000000...01110
# 111111...10001

# &
# 1011
# 0010
# 0010

# | (sau inclusiv)
# 1011
# 0010
# 1011 = 2

0 | 0 = 0
0 | 1 = 1
1 | 0 = 1
1 | 1 = 1

# ^ (sau exclusiv)
# 1011
# 0010
# 1001 = 9


0 ^ 0 = 0
0 ^ 1 = 1
1 ^ 0 = 1
1 ^ 1 = 0

# 7 >> 2 = 7 // (2^2)
# 000000000000111 >> 2
# 000000000000001 = 1


# 7 << 2 = 7 * (2^2)
# 000000000000111 << 2
# 000000000011100 = 28



print(11 & 2)

~x = -(x+1) = -x-1
-x = ~x+1


x >> 2
((x<<1)+x)<<1 = (x<<1)<<1 + x<<1 = x<<2 + x<<1

x & 1

# &
# a_1 a_2 ... a_n
#  0   0  ... 1

#  0   0  ... a_n  = x % 2


# a_1 a_2 ... a_n

# k \in {1, 2, ..., n}
# a_{n-k+1}

k = ...
(x >> (k-1)) & 1

# x - trebuie schimbat
# b - nu ne intereseaza

# |
# bbbbxbbbbbb
# 00001000000 - (1 << (k-1))

# &
# bbbbxbbbbbb
# 11110111111 - ~(1 << (k-1))

# GRESIT - o problema pentru un b = 0
# xor
# bbbbxbbbbbb
# 00001000000 - (1 << (k-1))



# &
# 0000010000000 - x
# 0000001111111 - x-1
# 0000000000000 = 0

if x & (x-1) == 0:
    print("putere a lui 2")
else:
    print("nu e putere a lui 2")


# Varianta cu 3 pahare
# aux = x
# x = y 
# y = aux

# Varianta cu xor

# x = x ^ y
# y = y ^ x = y ^ (x ^ y) = x (initial)
# x = x ^ y = y (initial)

# https://en.wikipedia.org/wiki/Signed_number_representations
x = 1001
y = 1100

# x ^ y = 

# &
# 0000 >> (shiftam iterativ)
# 0001


0, 1, 2

# 000
# 001
# 010
# 011
# 100
# 101
# 110
# 111




