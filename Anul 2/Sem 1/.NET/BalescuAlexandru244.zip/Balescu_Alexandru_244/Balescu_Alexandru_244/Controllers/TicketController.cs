﻿using Balescu_Alexandru_244.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Balescu_Alexandru_244.Controllers
{
    public class TicketController : Controller
    {
        private AppDbContext db = new AppDbContext();

        public class TicketIndex
        {
            public int Id { get; set; }
            public string TitluBilet { get; set; }
            public int Pret { get; set; }
            public DateTime Date { get; set; }
            public string Movie { get; set; }

        }

        [HttpGet]
        public IActionResult Index()
        {
            var tickets = db.Ticket.ToList();
            List<TicketIndex> list = new List<TicketIndex>();
            foreach (var ticket in tickets)
            {
                var ti = new TicketIndex();
                ti.Date = ticket.Date;
                ti.TitluBilet = ticket.TitluBilet;
                ti.Pret = ticket.Pret;
                ti.Movie = db.Movie.Find(ticket.MovieId).DenFilm;
                list.Add(ti);
            }

            ViewBag.tickets = list;
            return View();
        }

        [HttpGet]
        public IActionResult Show(string ticket_id)
        {

            int id;
            if (!int.TryParse(ticket_id, out id))
            {
                id = db.Ticket.Where(x => x.TitluBilet == ticket_id).ToList()[0].Id;
            }

            ViewBag.ticket = db.Ticket.Find(id);
            ViewBag.Movie = db.Movie.Find(ViewBag.ticket.MovieId);

            return View();
        }

        public IActionResult Delete(string ticket_id)
        {
            int id;
            if (!int.TryParse(ticket_id, out id))
            {
                id = db.Ticket.Where(x => x.TitluBilet == ticket_id).ToList()[0].Id;
            }

            Ticket ticket = db.Ticket.Find(id);

            db.Ticket.Remove(ticket);
            db.SaveChanges();


            return Redirect("/Ticket/Index");
        }

        [HttpGet]
        public IActionResult New()
        {
            ViewBag.movies = db.Movie.ToList();
            return View();
        }

        [HttpPost]
        public IActionResult New(Ticket newTicket)
        {
            newTicket.Date = DateTime.Now;
            var movie_name = (string)Request.Form["movie"];
            newTicket.MovieId = db.Movie.Where(x => x.DenFilm == movie_name).ToList()[0].Id;
            db.Add(newTicket);
            db.SaveChanges();

            return Redirect("/Ticket/Index");
        }

        [HttpGet]
        public IActionResult Edit(string ticket_id)
        {
            int id;
            if (!int.TryParse(ticket_id, out id))
            {
                id = db.Ticket.Where(x => x.TitluBilet == ticket_id).ToList()[0].Id;
            }

            ViewBag.ticket = db.Ticket.Find(id);
            ViewBag.movie = db.Movie.Find(ViewBag.ticket.MovieId);
            ViewBag.movies = db.Movie.ToList();

            return View();
        }

        [HttpPost]
        public IActionResult Edit(Ticket newTicket)
        {
            var movie_name = (string)Request.Form["movie"];
            newTicket.MovieId = db.Movie.Where(x => x.DenFilm == movie_name).ToList()[0].Id;

            Ticket oldTicket = db.Ticket.Where(x => x.TitluBilet == (string)Request.Form["oldticket"]).ToList()[0];
            newTicket.Id = oldTicket.Id;
            newTicket.Date = oldTicket.Date;

            db.Entry(oldTicket).State = EntityState.Detached;

            db.Update(newTicket);
            db.SaveChanges();

            return Redirect("/Ticket/Show/" + newTicket.Id);

        }

    }
}
