﻿using System.ComponentModel.DataAnnotations;

namespace Balescu_Alexandru_244.Models
{
    public class Movie
    {
        [Key]
        public int Id { get; set; }
        public string DenFilm { get; set; }

        public virtual ICollection<Ticket>? Ticket { get; set; }
    }
}
