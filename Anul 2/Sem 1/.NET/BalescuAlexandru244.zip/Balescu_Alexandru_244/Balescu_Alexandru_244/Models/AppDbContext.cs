﻿using Microsoft.EntityFrameworkCore;

namespace Balescu_Alexandru_244.Models
{
    public class AppDbContext : DbContext
    {
        public AppDbContext() : base()
        {
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Server=(localdb)\mssqllocaldb;Database=Exam;Trusted_Connection=True;MultipleActiveResultSets=true");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Movie>().HasData(
                new Movie { Id = 1, DenFilm = "M1" },
                new Movie { Id = 2, DenFilm = "M2" },
                new Movie { Id = 3, DenFilm = "M3" }
                );
            modelBuilder.Entity<Ticket>().HasData(
                new Ticket { Id = 1, TitluBilet = "T1", Pret = 10, Date = DateTime.Now, MovieId = 1 },
                new Ticket { Id = 2, TitluBilet = "T2", Pret = 20, Date = DateTime.Now, MovieId = 2 },
                new Ticket { Id = 3, TitluBilet = "T3", Pret = 30, Date = DateTime.Now, MovieId = 2 }
                );
        }

        public DbSet<Ticket> Ticket { get; set; }
        public DbSet<Movie> Movie { get; set; }

    }


}

