﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Balescu_Alexandru_244.Models
{
    public class Ticket
    {
        [Key]
        public int Id { get; set; }
        [Required(ErrorMessage = "Titlul biletului este necesar")]
        [StringLength(10, ErrorMessage = "Titlul nu poate avea mai mult de 10 de caractere")]
        public string TitluBilet { get; set; }
        [Required(ErrorMessage = "Pretul biletului este necesar")]
        [Range(1, 50, ErrorMessage = "Pretul trebuie sa fie intre 1 si 50")]
        public int Pret { get; set; }
        public DateTime Date { get; set; }

        [ForeignKey("Category")]
        public int? MovieId { get; set; }
        public Movie Movie { get; set; }
    }
}
