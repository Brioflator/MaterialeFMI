using Microsoft.EntityFrameworkCore;
using Balescu_Alexandru_244.Models;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();
builder.Services.AddDbContext<AppDbContext>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "NewTicket",
    pattern: "Ticket/New",
    defaults: new { controller = "Ticket", action = "New" }
    );

app.MapControllerRoute(
    name: "ShowTicket",
    pattern: "Ticket/Show/{ticket_id}",
    defaults: new { controller = "Ticket", action = "Show" }
    );

app.MapControllerRoute(
    name: "IndexTicket",
    pattern: "afisareBilete",
    defaults: new { controller = "Ticket", action = "Index" }
    );

app.MapControllerRoute(
    name: "EditTicket",
    pattern: "Ticket/Edit/{ticket_id}",
    defaults: new { controller = "Ticket", action = "Edit" }
    );

app.MapControllerRoute(
    name: "DeleteTicket",
    pattern: "Ticket/Delete/{ticket_id}",
    defaults: new { controller = "Ticket", action = "Delete" }
    );

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
