﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace BalescuAlexandru244.Migrations
{
    /// <inheritdoc />
    public partial class InitialMigration : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Movie",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DenFilm = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Movie", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Ticket",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TitluBilet = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Pret = table.Column<int>(type: "int", nullable: false),
                    Date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    MovieId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Ticket", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Ticket_Movie_MovieId",
                        column: x => x.MovieId,
                        principalTable: "Movie",
                        principalColumn: "Id");
                });

            migrationBuilder.InsertData(
                table: "Movie",
                columns: new[] { "Id", "DenFilm" },
                values: new object[,]
                {
                    { 1, "M1" },
                    { 2, "M2" },
                    { 3, "M3" }
                });

            migrationBuilder.InsertData(
                table: "Ticket",
                columns: new[] { "Id", "Date", "MovieId", "Pret", "TitluBilet" },
                values: new object[,]
                {
                    { 1, new DateTime(2023, 1, 21, 15, 7, 46, 510, DateTimeKind.Local).AddTicks(5055), 1, 10, "T1" },
                    { 2, new DateTime(2023, 1, 21, 15, 7, 46, 510, DateTimeKind.Local).AddTicks(5116), 2, 20, "T2" },
                    { 3, new DateTime(2023, 1, 21, 15, 7, 46, 510, DateTimeKind.Local).AddTicks(5118), 2, 30, "T3" }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Ticket_MovieId",
                table: "Ticket",
                column: "MovieId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Ticket");

            migrationBuilder.DropTable(
                name: "Movie");
        }
    }
}
