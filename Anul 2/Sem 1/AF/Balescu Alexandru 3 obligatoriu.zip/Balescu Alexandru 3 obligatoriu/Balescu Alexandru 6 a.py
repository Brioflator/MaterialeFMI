class Solution:
    def longestCommonSubsequence(self, text1: str, text2: str) -> int:
        matrix = [[0 for _ in range(len(text2) + 1)]
                  for _ in range(len(text1) + 1)]

        for y in range(len(text1) - 1, -1, -1):
            for x in range(len(text2) - 1, -1, -1):
                if text1[y] == text2[x]:
                    matrix[y][x] = 1 + matrix[y + 1][x + 1]
                else:
                    matrix[y][x] = max(matrix[y + 1][x], matrix[y][x + 1])

        return matrix[0][0]
